#ifndef MATRIXCALCULATOR_H
#define MATRIXCALCULATOR_H


class MatrixCalculator
{
    public:
        MatrixCalculator();


    protected:

    private:
};

#endif // MATRIXCALCULATOR_H
