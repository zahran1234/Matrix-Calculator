#ifndef MATRIX_H
#define MATRIX_H
#include <iostream>

using namespace std;


class matrix
{
    public:
        matrix();
         matrix(int rows,int columns);
        virtual ~matrix();

        friend istream &operator>>( istream  &input, matrix&matrix1 );

        friend ostream &operator<<( ostream &output, const matrix &matrix1 );
        matrix operator + ( const matrix& matrix2);
        matrix operator - ( const matrix & matrix2);
        matrix operator *( const matrix& matrix2);
         void print();
         matrix transpose();
         int get_columns();
         int get_rows();






        int rows ;
        int columns;
         double** mat;
};

#endif // MATRIX_H
