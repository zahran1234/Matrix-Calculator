#include "MatrixCalculator.h"
#include"matrix.h"

MatrixCalculator::MatrixCalculator()
{

    while (true)
    {
        int choice ;
        int rows1,columns1;
       cout<<" 1- Perform Matrix Addition"<<endl;
       cout<<" 2- Perform Matrix Subtraction"<<endl;
       cout<<" 3- Perform Matrix Multiplication"<<endl;
       cout<<" 4- Matrix Transpose"<<endl;
       cin>>choice;
       if (choice==1)
       {
           cout<<" enter the dimensions : "; cin>>rows1>>columns1;

           matrix  matrix1(rows1,columns1);
           matrix  matrix2(rows1,columns1);
            cout<<"enter matrix1 "<<endl;
            cin>>matrix1;
       cout<<"enter matrix2 "<<endl;
       cin >>matrix2;
       cout<<"matrix1+matrix2= "<<endl;
       matrix matrix3=matrix1+matrix2;
       cout<< matrix3<<endl;
       }
        else if  (choice==2)
       {
           cout<<" enter the dimensions : "; cin>>rows1>>columns1;
           matrix  matrix1(rows1,columns1);
           matrix  matrix2(rows1,columns1);
            cout<<"enter matrix1 "<<endl;
            cin>>matrix1;
       cout<<"enter matrix2 "<<endl;
       cin >>matrix2;
       cout<<"matrix1-matrix2= "<<endl;
       matrix matrix3=matrix1-matrix2;
       cout<< matrix3<<endl;
       }
        if (choice==3)
       {
           cout<<" enter the dimensions of matrix1 : "; cin>>rows1>>columns1;
           matrix  matrix1(rows1,columns1);
           cout<<" enter the dimensions of matrix2 : "; cin>>rows1>>columns1;
           matrix  matrix2(rows1,columns1);
           if (matrix1.get_columns()!=matrix2.get_rows())
           {
               cout<<"error"<<endl;
           }
           else
           {
              cout<<"enter matrix1 "<<endl;
            cin>>matrix1;
       cout<<"enter matrix2 "<<endl;
       cin >>matrix2;
       cout<<"matrix1*matrix2= "<<endl;
       matrix matrix3 =matrix1*matrix2;
       cout<< matrix3<<endl;
           }


       }
       else if (choice==4)
       {

           cout<<"enter the dimensions : ";
           cin>>rows1>>columns1;
           matrix  matrix1(rows1,columns1);
           cin>>matrix1;
           cout<<matrix1.transpose()<<endl;

       }



    }
}


