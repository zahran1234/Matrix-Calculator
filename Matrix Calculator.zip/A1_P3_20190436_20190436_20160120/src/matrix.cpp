#include "matrix.h"
//template <class t>
matrix::matrix()
{

}

matrix:: matrix(int rows,int columns)
{
      this->columns=columns;
        this->rows=rows;
        mat=new double*[rows];
        for (int i=0;i<rows;i++)
        {
         mat[i]=new double[columns];

        }
}

matrix::~matrix()
{
     for(int i = 0; i < rows; ++i) {
          delete [] mat[i];
     }
    delete [] mat;
}

  istream &operator>>( istream  &input, matrix &matrix1 )
    {
       for (int i=0;i<matrix1.rows;i++)
        {
            for (int x=0;x<matrix1.columns;x++)
                {
                    cout<<"matrix["<<i+1<<"]["<<x+1<<"] :";
                  input>>matrix1.mat[i][x];
                  cout<<endl;

                }
                cout<<endl;
        }
        return input;
    }

    ostream &operator<<( ostream &output, const matrix &matrix1 )
    {
        for (int i=0;i<matrix1.rows;i++)
        {
            for (int x=0;x<matrix1.columns;x++)
                {
                    output<<matrix1.mat[i][x]<<"    ";
                }
                 output<<endl;
        }
       return output;
    }

    matrix   matrix :: operator + ( const matrix& matrix2)
    {
          matrix matrix3(matrix2.rows,matrix2.columns);
        for (int i=0;i<matrix3.rows;i++)
        {
            for (int x=0;x<matrix3.columns;x++)
                matrix3.mat[i][x]=this->mat[i][x]+matrix2.mat[i][x];
        }
        return matrix3;
    }
    //template <class t>
     matrix matrix :: operator - ( const matrix& matrix2)
     {

        matrix matrix3(matrix2.rows,matrix2.columns);
        for (int i=0;i<rows;i++)
        {
            for (int x=0;x<columns;x++)
                matrix3.mat[i][x]=this->mat[i][x]-matrix2.mat[i][x];
        }
        return matrix3;



     }

     matrix  matrix:: operator *( const matrix& matrix2)
     {
          matrix matrix3(this->rows,matrix2.columns);

              for (int i=0;i<this->rows;i++)
              {
                  for (int x=0;x<matrix2.columns;x++)
                  {
                      for (int y=0;y<this->columns;y++)
                      {
                          matrix3.mat[i][x]+=this->mat[i][y]*matrix2.mat[y][x];
                      }
                  }
              }
              return matrix3;



      }
      void matrix::print()
      {

        for(int i=0;i<rows;i++)
        {
            for (int x=0;x<columns;x++)
                cout<<mat[i][x]<<"    ";
            cout<<endl;
        }

      }

      matrix matrix:: transpose()
      {
          matrix matrix2(columns,rows);
          for (int i=0;i<columns;i++)
          {
              for (int x=0;x<rows;x++)
              {
                  matrix2.mat[i][x]=this->mat[x][i];
              }
          }
            return matrix2;
      }

      int matrix::get_columns()
      {
          return this->columns;
      }

      int matrix::get_rows()
      {
          return this->rows;
      }
