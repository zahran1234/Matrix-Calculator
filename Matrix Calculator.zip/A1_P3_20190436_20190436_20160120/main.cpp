#include <iostream>

using namespace std;
#include"matrix.h"
#include"MatrixCalculator.h"
int main()
{
    MatrixCalculator m ;







    return 0;
}
